function simpleFunction() {
}

function simpleFunctionNested(a, b) {
    function nested(c) {
    }
}

(function() {
    var someFunction = function(a, b) {
    };
    
    someFunction.bla = function() {
    };
})();

class SomeClass {
    method(x) {
        
    }
}