console.log("test");

window.onload = function(){
    document.body.style.borderColor = "green";
}