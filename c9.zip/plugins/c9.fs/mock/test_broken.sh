
foo() {
    echo foo
}

bar() {
    echo bar
}

# This file has a syntax error at the end
if true; then
   echo "dude, where's my fi?"