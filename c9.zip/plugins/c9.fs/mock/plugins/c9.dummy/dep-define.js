define(function(require, exports, module) {
    "use strict";

    module.exports.export1 = function() {};

    exports.export2 = function() {};
});