function onClick() {
    say("hi");
}

function say(text) {
    alert(text);
}